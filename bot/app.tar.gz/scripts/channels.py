#!/usr/bin/env python3
"""
channels.py — мульти-канальная публикация (fan-out) поверх существующего Telegram-паблишера.

Основной TG-канал публикует bot.publish_to_channel (как раньше).
Здесь — ДОПОЛНИТЕЛЬНЫЕ каналы российского контура: VK, Одноклассники, MAX, Яндекс Дзен.

Включаются переменной окружения EXTRA_CHANNELS (через запятую), напр.:
    EXTRA_CHANNELS=vk,dzen,ok,max
Если пусто — publish_extra() ничего не делает (поведение бота не меняется).

Каждый паблишер возвращает bool (успех). publish_extra() отдаёт список статусов
[(channel, ok, info)] — бот показывает их владельцу после публикации.
"""
import logging
import os
import re
import random
from pathlib import Path

import requests

import scripts.poster as poster

log = logging.getLogger("channels")

# --- Telegram (для зеркала Дзена и переиспользования) ---
TG_BOT_TOKEN = os.getenv("BOT_TOKEN")
DZEN_MIRROR_CHAT_ID = os.getenv("DZEN_MIRROR_CHAT_ID")  # публичный TG-канал-зеркало для @zen_sync_bot

# --- VK ---
VK_GROUP_ID = os.getenv("VK_GROUP_ID")                       # число (без минуса)
VK_TOKEN = os.getenv("VK_TOKEN")                             # ключ сообщества (для wall.post)
VK_UPLOAD_TOKEN = os.getenv("VK_UPLOAD_TOKEN") or VK_TOKEN   # токен юзера-админа (для загрузки медиа)
VK_API_V = os.getenv("VK_API_V", "5.199")

# --- Одноклассники / MAX — подключим после получения доступов ---
OK_GROUP_ID = os.getenv("OK_GROUP_ID")
MAX_TOKEN = os.getenv("MAX_TOKEN")
MAX_CHAT_ID = os.getenv("MAX_CHAT_ID")


def enabled_extra() -> list[str]:
    raw = os.getenv("EXTRA_CHANNELS", "")
    return [c.strip().lower() for c in raw.split(",") if c.strip()]


def _plain(body: str) -> str:
    """Markdown → плоский текст (VK/OK не рендерят разметку)."""
    t = body or ""
    t = re.sub(r"\*\*(.+?)\*\*", r"\1", t)   # **bold**
    t = re.sub(r"__(.+?)__", r"\1", t)
    t = re.sub(r"(?<!\w)\*(.+?)\*(?!\w)", r"\1", t)
    t = re.sub(r"`{1,3}", "", t)
    return t.strip()


# ---------------------------------------------------------------------------
# Telegram-отправка в произвольный чат (зеркало Дзена / фолбэк)
# ---------------------------------------------------------------------------
def _tg_send_to(chat_id: str, body: str, image_path: str | None) -> bool:
    if not (TG_BOT_TOKEN and chat_id):
        return False
    html = poster.markdown_to_html(poster.sanitize_for_telegram(body))
    plain_len = len(poster.sanitize_for_telegram(body))
    api = f"https://api.telegram.org/bot{TG_BOT_TOKEN}"
    try:
        if image_path and Path(image_path).exists() and plain_len <= poster.TELEGRAM_CAPTION_MAX:
            with open(image_path, "rb") as f:
                r = requests.post(f"{api}/sendPhoto",
                                  data={"chat_id": chat_id, "caption": html, "parse_mode": "HTML"},
                                  files={"photo": f}, timeout=90)
        else:
            r = requests.post(f"{api}/sendMessage",
                              data={"chat_id": chat_id, "text": html, "parse_mode": "HTML"},
                              timeout=60)
        ok = r.ok and r.json().get("ok", False)
        if not ok:
            log.warning("tg_send_to %s: %s", chat_id, r.text[:200])
        return ok
    except Exception as exc:
        log.warning("tg_send_to %s: %s", chat_id, exc)
        return False


# ---------------------------------------------------------------------------
# Яндекс Дзен — через официальный синхробот @zen_sync_bot: публикуем в
# публичный TG-канал-зеркало, Дзен сам его зеркалит. Первая строка ≤140 → заголовок.
# ---------------------------------------------------------------------------
def _dzen_format(body: str) -> str:
    lines = (body or "").splitlines()
    if lines:
        head = _plain(lines[0])
        if len(head) > 140:
            head = head[:137].rstrip() + "…"
        lines[0] = head
    return "\n".join(lines)


def publish_dzen(body: str, image_path: str | None, image_filename: str | None) -> bool:
    if not DZEN_MIRROR_CHAT_ID:
        log.info("dzen: DZEN_MIRROR_CHAT_ID не задан — пропуск")
        return False
    return _tg_send_to(DZEN_MIRROR_CHAT_ID, _dzen_format(body), image_path)


# ---------------------------------------------------------------------------
# ВКонтакте — wall.post от имени сообщества (+ загрузка обложки на стену)
# ---------------------------------------------------------------------------
def _vk_call(method: str, params: dict, token: str) -> dict:
    p = dict(params, access_token=token, v=VK_API_V)
    r = requests.post(f"https://api.vk.com/method/{method}", data=p, timeout=60)
    d = r.json()
    if "error" in d:
        raise RuntimeError(f"VK {method}: {d['error'].get('error_code')} {d['error'].get('error_msg')}")
    return d["response"]


def _vk_upload_photo(image_path: str) -> str | None:
    gid = abs(int(VK_GROUP_ID))
    srv = _vk_call("photos.getWallUploadServer", {"group_id": gid}, VK_UPLOAD_TOKEN)
    with open(image_path, "rb") as f:
        up = requests.post(srv["upload_url"], files={"photo": f}, timeout=90).json()
    if not up.get("photo") or up.get("photo") == "[]":
        log.warning("vk upload: пустой ответ загрузки")
        return None
    saved = _vk_call("photos.saveWallPhoto",
                     {"group_id": gid, "server": up["server"], "photo": up["photo"], "hash": up["hash"]},
                     VK_UPLOAD_TOKEN)
    ph = saved[0]
    return f"photo{ph['owner_id']}_{ph['id']}"


def publish_vk(body: str, image_path: str | None, image_filename: str | None) -> bool:
    if not (VK_TOKEN and VK_GROUP_ID):
        log.info("vk: VK_TOKEN/VK_GROUP_ID не заданы — пропуск")
        return False
    attachments = ""
    if image_path and Path(image_path).exists():
        try:
            att = _vk_upload_photo(image_path)
            if att:
                attachments = att
        except Exception as exc:
            log.warning("vk upload photo: %s (публикую без фото)", exc)
    params = {
        "owner_id": -abs(int(VK_GROUP_ID)),
        "from_group": 1,
        "message": _plain(body),
        "random_id": random.randint(1, 2_000_000_000),
    }
    if attachments:
        params["attachments"] = attachments
    _vk_call("wall.post", params, VK_TOKEN)
    return True


# ---------------------------------------------------------------------------
# Заглушки — подключим после получения доступов
# ---------------------------------------------------------------------------
def publish_ok(body: str, image_path: str | None, image_filename: str | None) -> bool:
    log.info("ok: паблишер ещё не подключён (ждём GROUP_CONTENT + токены)")
    return False


def publish_max(body: str, image_path: str | None, image_filename: str | None) -> bool:
    if not (MAX_TOKEN and MAX_CHAT_ID):
        log.info("max: MAX_TOKEN/MAX_CHAT_ID не заданы — пропуск")
        return False
    log.info("max: паблишер ещё не подключён (каркас)")
    return False


CHANNELS = {
    "vk": publish_vk,
    "dzen": publish_dzen,
    "ok": publish_ok,
    "max": publish_max,
}


def publish_extra(body: str, image_path: str | None = None,
                  image_filename: str | None = None) -> list[tuple[str, bool, str]]:
    """Публикует во все ВКЛЮЧЁННЫЕ доп.каналы (кроме основного Telegram). Список статусов."""
    results: list[tuple[str, bool, str]] = []
    for ch in enabled_extra():
        fn = CHANNELS.get(ch)
        if not fn:
            results.append((ch, False, "неизвестный канал"))
            continue
        try:
            ok = fn(body, image_path, image_filename)
            results.append((ch, bool(ok), "опубликовано" if ok else "не настроен/пропуск"))
        except Exception as exc:
            log.exception("publish %s", ch)
            results.append((ch, False, str(exc)[:150]))
    return results
