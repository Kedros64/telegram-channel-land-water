#!/usr/bin/env python3
"""
genapi.py — клиент gen-api.ru (РФ, рубли, гео-независимо).
Картинки: flux-2 / seedream — текст-фри фон (надпись накладываем сами).
Голос: whisper STT по URL аудио.
Async-флоу: POST /api/v1/networks/{model} -> request_id -> GET /api/v1/request/get/{id}.
"""
import logging
import os
import time

import requests

log = logging.getLogger("genapi")

GENAPI_KEY = os.getenv("GENAPI_KEY")
BASE = "https://api.gen-api.ru/api/v1"
IMAGE_MODEL = os.getenv("GENAPI_IMAGE_MODEL", "nano-banana-2")  # nano-banana-2 | flux-2 | seedream-v4-5
RESOLUTION = os.getenv("GENAPI_RESOLUTION", "0.5K")            # 0.5K | 1K | 2K | 4K (для nano-banana)
FLUX_MODE = os.getenv("GENAPI_FLUX_MODE", "standard")          # standard | turbo | flash (для flux-2)

# aspect_ratio → width/height (для flux/seedream, если вдруг переключимся)
_ASPECT_WH = {"1:1": (1024, 1024), "2:3": (1024, 1536), "9:16": (1024, 1536),
              "16:9": (1536, 1024), "3:2": (1536, 1024)}


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {GENAPI_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _create(network: str, body: dict) -> int:
    r = requests.post(f"{BASE}/networks/{network}", headers=_headers(), json=body, timeout=60)
    if not r.ok:
        raise RuntimeError(f"gen-api create {network}: HTTP {r.status_code} {r.text[:300]}")
    d = r.json()
    rid = d.get("request_id") or d.get("id")
    if not rid:
        raise RuntimeError(f"gen-api create {network}: нет request_id в ответе {d}")
    return rid


def _poll(request_id: int, timeout: int = 240) -> dict:
    deadline = time.time() + timeout
    delay = 3
    while time.time() < deadline:
        r = requests.get(f"{BASE}/request/get/{request_id}", headers=_headers(), timeout=30)
        if r.ok:
            d = r.json()
            st = str(d.get("status", "")).lower()
            if st in ("success", "completed", "done"):
                return d
            if st in ("error", "failed"):
                raise RuntimeError(f"gen-api task {request_id} failed: {str(d)[:300]}")
        time.sleep(delay)
        delay = min(delay + 1, 8)
    raise TimeoutError(f"gen-api poll timeout (request {request_id})")


def generate_image_url(prompt: str, aspect_ratio: str = "1:1") -> str | None:
    """Генерит кликбейт-обложку (Nano Banana 2 сама рисует и русскую подпись).
    Возвращает URL готовой картинки или None."""
    if not GENAPI_KEY:
        log.warning("GENAPI_KEY не задан — картинка пропущена")
        return None
    if IMAGE_MODEL.startswith("nano-banana"):
        body = {"prompt": prompt[:1800], "resolution": RESOLUTION,
                "aspect_ratio": aspect_ratio, "is_sync": False}
    else:  # flux-2 / seedream — по width/height
        w, h = _ASPECT_WH.get(aspect_ratio, (1024, 1024))
        body = {"prompt": prompt[:1800], "width": w, "height": h, "num_images": 1,
                "output_format": "png", "translate_input": False, "is_sync": False}
        if IMAGE_MODEL.startswith("flux-2"):
            body["model"] = FLUX_MODE
    rid = _create(IMAGE_MODEL, body)
    d = _poll(rid, timeout=180)
    res = d.get("result") or []
    url = res[0] if isinstance(res, list) and res else (res if isinstance(res, str) else None)
    if not url:
        log.warning("gen-api image %s: пустой result %s", rid, str(d)[:200])
    return url


def download(url: str, dest_path: str) -> str:
    r = requests.get(url, timeout=90)
    r.raise_for_status()
    with open(dest_path, "wb") as f:
        f.write(r.content)
    return dest_path


def transcribe(audio_url: str, language: str = "ru") -> str:
    """Транскрибация аудио по публичному URL (напр. Telegram file URL). Возвращает текст."""
    if not GENAPI_KEY:
        raise RuntimeError("GENAPI_KEY не задан")
    rid = _create("whisper", {
        "audio_url": audio_url,
        "language": language,
        "task": "transcribe",
        "is_sync": False,
    })
    d = _poll(rid, timeout=180)
    res = d.get("result")
    # whisper может вернуть текст в result (строка / [строка]) либо в full_response[*].text
    if isinstance(res, list) and res:
        parts = []
        for x in res:
            if isinstance(x, str):
                parts.append(x)
            elif isinstance(x, dict):
                parts.append(x.get("text") or x.get("transcription") or "")
        text = " ".join(p for p in parts if p).strip()
        if text:
            return text
    if isinstance(res, str) and res.strip():
        return res.strip()
    fr = d.get("full_response")
    if isinstance(fr, list) and fr and isinstance(fr[0], dict):
        return str(fr[0].get("text") or fr[0].get("transcription") or "").strip()
    log.warning("whisper %s: не нашёл текст в ответе %s", rid, str(d)[:300])
    return ""
