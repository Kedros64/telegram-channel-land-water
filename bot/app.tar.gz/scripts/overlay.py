#!/usr/bin/env python3
"""
overlay.py — наложение кликбейт-надписи (CAPS, жирный шрифт + чёрная обводка)
на текст-фри фон. Кириллица рендерится нами → всегда чистая, любой моделью фона.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

FONT_PATH = str(Path(__file__).parent.parent / "assets" / "Montserrat-Black.ttf")


def _wrap_to_lines(text: str, font: ImageFont.FreeTypeFont, draw, max_w: int, max_lines: int):
    """Переносит текст по словам так, чтобы каждая строка влезала в max_w, ≤ max_lines."""
    words = text.split()
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=font) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines if len(lines) <= max_lines else None


def render_caption(
    image_path: str,
    caption: str,
    position: str = "top",
    fill=(255, 255, 255),
    stroke=(0, 0, 0),
) -> str:
    """
    Накладывает caption на картинку по месту (image_path перезаписывается).
    Автоподбор размера шрифта, перенос до 2 строк, белый текст с толстой чёрной обводкой
    и мягкой тенью — как на обложках YouTube. Возвращает image_path.
    """
    caption = (caption or "").strip().strip("«»\"'").upper()
    if not caption:
        return image_path

    img = Image.open(image_path).convert("RGBA")
    W, H = img.size
    draw = ImageDraw.Draw(img)

    margin_x = int(W * 0.06)
    max_w = W - 2 * margin_x
    max_block_h = int(H * 0.30)          # надпись занимает не больше ~30% высоты
    max_lines = 1 if len(caption) <= 12 else 2

    # автоподбор кегля: от крупного вниз, пока влезает по ширине и высоте
    best = None
    size = int(H * 0.16)
    while size >= 24:
        font = ImageFont.truetype(FONT_PATH, size)
        lines = _wrap_to_lines(caption, font, draw, max_w, max_lines)
        if lines:
            line_h = font.getbbox("Ё")[3] - font.getbbox("Ё")[1]
            gap = int(size * 0.12)
            block_h = len(lines) * line_h + (len(lines) - 1) * gap
            widest = max(draw.textlength(ln, font=font) for ln in lines)
            if widest <= max_w and block_h <= max_block_h:
                best = (font, lines, line_h, gap, block_h)
                break
        size -= 4
    if not best:
        font = ImageFont.truetype(FONT_PATH, 28)
        best = (font, [caption], font.getbbox("Ё")[3], 4, font.getbbox("Ё")[3])

    font, lines, line_h, gap, block_h = best
    stroke_w = max(3, int(font.size * 0.10))

    if position == "top":
        y = int(H * 0.05)
    elif position == "bottom":
        y = H - block_h - int(H * 0.06)
    else:  # center
        y = (H - block_h) // 2

    ascent = font.getbbox("Ё")[1]
    for ln in lines:
        w = draw.textlength(ln, font=font)
        x = (W - w) / 2
        # мягкая тень
        draw.text((x + stroke_w, y + stroke_w - ascent), ln, font=font,
                  fill=(0, 0, 0, 120))
        # текст с обводкой
        draw.text((x, y - ascent), ln, font=font, fill=fill,
                  stroke_width=stroke_w, stroke_fill=stroke)
        y += line_h + gap

    img.convert("RGB").save(image_path, "PNG")
    return image_path
