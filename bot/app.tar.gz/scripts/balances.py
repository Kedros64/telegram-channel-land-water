#!/usr/bin/env python3
"""
balances.py — проверка балансов для ежедневного мониторинга:
  • gen-api.ru — сервис генерации фото (рубли);
  • Timeweb    — сервер, на котором живёт бот (рубли + сколько часов осталось).

Оба API российские и доступны с нашего VPS.
"""
import logging
import os

import requests

log = logging.getLogger("balances")

GENAPI_KEY = os.getenv("GENAPI_KEY")
TIMEWEB_TOKEN = os.getenv("TIMEWEB_TOKEN")


def genapi_balance() -> float | None:
    """Баланс gen-api.ru в рублях. GET /api/v1/user → поле balance. None при ошибке."""
    if not GENAPI_KEY:
        log.warning("genapi_balance: GENAPI_KEY не задан")
        return None
    try:
        r = requests.get(
            "https://api.gen-api.ru/api/v1/user",
            headers={"Authorization": f"Bearer {GENAPI_KEY}", "Accept": "application/json"},
            timeout=30,
        )
        r.raise_for_status()
        return float(r.json().get("balance"))
    except Exception as exc:
        log.warning("genapi_balance: %s", exc)
        return None


def timeweb_finances() -> dict | None:
    """Финансы Timeweb: {'balance': ₽, 'hours_left': ч, 'monthly_cost': ₽/мес, ...}. None при ошибке."""
    if not TIMEWEB_TOKEN:
        log.warning("timeweb_finances: TIMEWEB_TOKEN не задан")
        return None
    try:
        r = requests.get(
            "https://api.timeweb.cloud/api/v1/account/finances",
            headers={"Authorization": f"Bearer {TIMEWEB_TOKEN}"},
            timeout=30,
        )
        r.raise_for_status()
        return r.json().get("finances") or None
    except Exception as exc:
        log.warning("timeweb_finances: %s", exc)
        return None
