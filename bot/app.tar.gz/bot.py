#!/usr/bin/env python3
"""
bot.py — Telegram-бот предварительного согласования постов канала «Землю и Воду».

Поток:
  расписание → генерация поста-кандидата (reuse scripts/monitor.py)
  → отправка владельцу на согласование (фото + текст + 3 кнопки)
  → «✅ Ок»       → публикация в канал (reuse scripts/poster.py)
  → «✍️ Доработай» → выбор [Картинку/Текст/Картинку+текст] → голосовое →
                     транскрибация (OpenAI Whisper) → пересборка → новая итерация
  → «🗑 Отменить»  → отмена без замены, расписание продолжается
  → нет ответа за APPROVAL_TIMEOUT_MIN минут → авто-публикация
"""

import asyncio
import base64
import io
import json
import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests
from aiohttp import web
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from dotenv import load_dotenv

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LinkPreviewOptions,
    Message,
)

load_dotenv()

# --- переиспользуем существующие генерацию и публикацию ------------------------
import scripts.monitor as monitor
import scripts.poster as poster
import scripts.genapi as genapi
import scripts.overlay as overlay
import scripts.channels as channels
import scripts.balances as balances

# ---------------------------------------------------------------------------
# Конфигурация
# ---------------------------------------------------------------------------
BOT_TOKEN = os.getenv("BOT_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", "8118456427"))
CHANNEL_ID = os.getenv("CHANNEL_ID")
DATA_DIR = Path(os.getenv("DATA_DIR", "/opt/app/data"))
STATE_FILE = DATA_DIR / "state.json"
APPROVAL_TIMEOUT_MIN = int(os.getenv("APPROVAL_TIMEOUT_MIN", "30"))
# Ежедневный мониторинг балансов (10:00 МСК = 07:00 UTC)
GENAPI_MIN_BALANCE = float(os.getenv("GENAPI_MIN_BALANCE", "100"))   # ₽ — ниже → напомнить пополнить
SERVER_ALERT_DAYS = int(os.getenv("SERVER_ALERT_DAYS", "5"))         # дней до конца оплаты сервера
BALANCE_CHECK_UTC = (7, 0)                                           # 10:00 МСК
PORT = int(os.getenv("PORT", "3000"))
MOSCOW_OFFSET = timedelta(hours=3)

# GitHub — публичный raw-URL картинки (Black Hole сервер сам её не отдаёт)
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_REPO = os.getenv("GITHUB_REPO", "Kedros64/telegram-channel-land-water")
GITHUB_BRANCH = os.getenv("GITHUB_BRANCH", "main")

# 4 слота/день. МСК 9:11 / 12:15 / 15:35 / 18:45 → UTC (−3):
SLOTS_UTC = [(6, 11), (9, 15), (12, 35), (15, 45)]

WHISPER_MODEL = "gpt-4o-mini-transcribe"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("bot")

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# ---------------------------------------------------------------------------
# Состояние (одно «на согласовании» за раз; при желании расширяется в очередь)
# ---------------------------------------------------------------------------
# pending = {id, body, raw_text, image_path, image_filename, post_type,
#            created_at, text_msg_id, stage, rework_what}
#   stage: "await_approval" | "await_rework_choice" | "await_voice"
pending: dict | None = None
_lock = asyncio.Lock()


def moscow_now() -> datetime:
    return datetime.now(timezone.utc) + MOSCOW_OFFSET


def save_state() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(
        json.dumps(pending, ensure_ascii=False, default=str), encoding="utf-8"
    )


def load_state() -> None:
    global pending
    if STATE_FILE.exists():
        try:
            pending = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            log.warning("Не удалось прочитать state.json: %s", exc)
            pending = None


# ---------------------------------------------------------------------------
# Ручные посты «на замену слоту» (из голосовой темы) — очередь по (дата, слот)
# ---------------------------------------------------------------------------
OVERRIDES_FILE = DATA_DIR / "overrides.json"


def _load_overrides() -> dict:
    try:
        return json.loads(OVERRIDES_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_overrides(d: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OVERRIDES_FILE.write_text(json.dumps(d, ensure_ascii=False, default=str), encoding="utf-8")


def add_override(date: str, slot: int, cand: dict) -> None:
    d = _load_overrides()
    d.setdefault(date, {})[str(slot)] = cand
    _save_overrides(d)


def pop_override(date: str, slot: int) -> dict | None:
    d = _load_overrides()
    day = d.get(date, {})
    cand = day.pop(str(slot), None)
    if cand is not None:
        if day:
            d[date] = day
        else:
            d.pop(date, None)
        _save_overrides(d)
    return cand


def remaining_slots(now_msk) -> list[tuple[int, str]]:
    """Оставшиеся сегодня плановые слоты (индекс, 'ЧЧ:ММ') позже текущего времени."""
    mins = now_msk.hour * 60 + now_msk.minute
    out = []
    for i, (h, m) in enumerate(monitor.POST_SLOTS_MSK, 1):
        if h * 60 + m > mins + 2:
            out.append((i, f"{h:02d}:{m:02d}"))
    return out


def next_publish_slot(now_msk) -> tuple[str, int, str]:
    """Ближайший плановый слот впереди: (дата 'ГГГГ-ММ-ДД', индекс, 'ЧЧ:ММ').
    Сегодня — первый оставшийся; если сегодня слотов нет — завтра, слот 1."""
    rem = remaining_slots(now_msk)
    if rem:
        idx, hm = rem[0]
        return now_msk.strftime("%Y-%m-%d"), idx, hm
    tomorrow = (now_msk + timedelta(days=1)).strftime("%Y-%m-%d")
    h, m = monitor.POST_SLOTS_MSK[0]
    return tomorrow, 1, f"{h:02d}:{m:02d}"


# ---------------------------------------------------------------------------
# Обложка: текст-фри фон (gen-api.ru) + наложение подписи (overlay)
# ---------------------------------------------------------------------------
def make_cover(raw_text: str, now_msk: datetime, extra_prompt: str = "") -> str | None:
    """Генерит кликбейт-обложку через Nano Banana 2 (модель сама рисует русскую подпись).
    Путь к PNG или None."""
    if not genapi.GENAPI_KEY:
        log.warning("GENAPI_KEY не задан — картинка пропущена")
        return None
    prompt = monitor.extract_image_prompt(raw_text)
    if not prompt:
        log.warning("make_cover: не нашёл промпт в блоке ВИЗУАЛ — картинка пропущена")
        return None
    # снять кавычки вокруг подписи + добавить разовую правку и постоянные правила автора
    prompt = monitor.finalize_image_prompt(prompt, extra_prompt)
    fmt = monitor.extract_image_format(raw_text)
    aspect = monitor.IMAGE_ASPECT_BY_FORMAT.get(fmt, "1:1")
    try:
        url = genapi.generate_image_url(prompt, aspect)
        if not url:
            log.warning("make_cover: gen-api вернул пустой URL")
            return None
        fname = now_msk.strftime("%Y-%m-%d_%H-%M-%S") + "_cover.png"
        path = str(monitor.POSTS_DIR / fname)
        genapi.download(url, path)
        log.info("Обложка готова: %s (формат=%s, %s)", fname, fmt, aspect)
        return path
    except Exception as exc:
        log.warning("Не удалось сделать обложку: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Генерация кандидата (reuse monitor)
# ---------------------------------------------------------------------------
def generate_candidate(refresh: bool = True, ignore_limit: bool = False) -> dict | None:
    """Синхронно генерит один пост-кандидат. Возвращает dict или None (нет материала).
    refresh=False — не перечитывать источники, брать из готового пула (быстрая перегенерация).
    ignore_limit=True — игнорировать суточный лимит (ручные /test и «Другая тема»)."""
    if not monitor.DEEPSEEK_API_KEY:
        log.error("DEEPSEEK_API_KEY не задан")
        return None

    now_msk = moscow_now()
    post_type, include_cta = monitor.day_plan(now_msk)
    today = now_msk.strftime("%Y-%m-%d")

    pool = monitor.load_articles_pool()
    if refresh:
        sources = monitor.read_sources()
        all_articles = monitor.collect_all_articles(sources)
        if all_articles:
            pre = monitor.pre_filter_by_keywords(all_articles)
            relevant = monitor.filter_relevant_with_deepseek(pre) if pre else []
            pool = monitor.merge_into_pool(pool, relevant, now_msk)

    selected = monitor.select_posts_from_pool(pool, today, count=1, ignore_daily_limit=ignore_limit)
    if not selected:
        monitor.save_articles_pool(pool)
        return None

    # источник для сверки уникальности (сохраняем ДО валидации, которая может обнулить url)
    source_url = selected[0].get("url", "")
    source_name = selected[0].get("source_name", "")

    urls = {a["url"] for a in selected}
    for a in pool:
        if a.get("url") in urls:
            a["used"] = True
            a["used_at"] = now_msk.isoformat()
    monitor.save_articles_pool(pool)

    session = monitor.make_session()
    for a in selected:
        u = a.get("url", "")
        if u and not monitor.validate_url(u, session):
            a["url"] = ""

    article = selected[0]
    raw_text = monitor.generate_post(article, post_type=post_type, include_cta=include_cta)
    if raw_text.strip().upper().startswith("SKIP"):
        log.info("Материал отклонён моделью (SKIP)")
        return None

    image_path = make_cover(raw_text, now_msk)

    body = poster._clean_post_body(raw_text) or raw_text.strip()
    if include_cta and "vodazem.ru" not in body.lower():      # реклама-слот → ссылка на сайт
        body = body.rstrip() + "\n\n🌐 vodazem.ru"
    return {
        "id": now_msk.strftime("%m%d%H%M%S"),
        "body": body,
        "raw_text": raw_text,
        "image_path": image_path,
        "image_filename": Path(image_path).name if image_path else None,
        "post_type": post_type,
        "include_cta": include_cta,
        "kind": "scheduled",
        "source_url": source_url,
        "source_name": source_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


VOICE_POST_ARTICLE_TITLE = "Тема от автора (голосовое)"


def generate_voice_candidate(dictation: str) -> dict | None:
    """Генерит пост из надиктованной автором темы (тот же формат, что обычный пост)."""
    now_msk = moscow_now()
    article = {
        "title": VOICE_POST_ARTICLE_TITLE,
        "content": dictation,
        "source_name": "",
        "url": "",
        "published": now_msk.strftime("%d.%m.%Y"),
    }
    raw_text = monitor.generate_post(article, post_type="regular", include_cta=False)
    if raw_text.strip().upper().startswith("SKIP"):
        return None
    image_path = make_cover(raw_text, now_msk)
    body = poster._clean_post_body(raw_text) or raw_text.strip()
    return {
        "id": now_msk.strftime("%m%d%H%M%S"),
        "body": body,
        "raw_text": raw_text,
        "image_path": image_path,
        "image_filename": Path(image_path).name if image_path else None,
        "post_type": "regular",
        "kind": "voice",
        "dictation": dictation,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Доработка (reuse DeepSeek / image gen)
# ---------------------------------------------------------------------------
REWORK_PROMPT = """\
Ты — редактор Telegram-канала компании о земле и воде. Ниже текущий пост и правка автора.
Перепиши пост с учётом правки, сохранив живой человеческий тон от лица КОМАНДЫ компании
(мы/наша команда) и ТОЧНО тот же выходной формат: блок «**ГОТОВЫЙ ПОСТ:**», затем текст,
затем «**ВИЗУАЛ:**» с «Формат:» и «Prompt (EN):».

ТЕКУЩИЙ ПОСТ:
{current}

ПРАВКА АВТОРА (расшифровка голосового):
{correction}
"""


def rework_candidate(cand: dict, what: str, correction: str) -> dict:
    """Применяет правку к кандидату. what: 'text' | 'image' | 'both'."""
    now_msk = moscow_now()
    raw_text = cand["raw_text"]

    if what in ("text", "both"):
        raw_text = monitor.deepseek_generate(
            REWORK_PROMPT.format(current=cand["raw_text"], correction=correction)
        )
        cand["raw_text"] = raw_text
        cand["body"] = poster._clean_post_body(raw_text) or raw_text.strip()

    if what in ("image", "both"):
        # для правки только картинки — добавим пожелание автора в промпт фона
        extra = f"Изменения по правке автора: {correction}" if (what == "image" and correction) else ""
        p = make_cover(raw_text, now_msk, extra_prompt=extra)
        if p:
            cand["image_path"] = str(p)
            cand["image_filename"] = Path(p).name
    return cand


# ---------------------------------------------------------------------------
# Публикация в канал (reuse poster + коммит картинки в GitHub для raw-URL)
# ---------------------------------------------------------------------------
def github_put_image(filename: str, local_path: str) -> bool:
    """Коммитит PNG в репозиторий, чтобы получить публичный raw-URL для превью."""
    if not GITHUB_TOKEN:
        return False
    api = f"https://api.github.com/repos/{GITHUB_REPO}/contents/posts/{filename}"
    hdr = {"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json",
           "User-Agent": "landwater-bot"}
    content = base64.b64encode(open(local_path, "rb").read()).decode()
    # sha, если файл уже есть
    sha = None
    r = requests.get(api + f"?ref={GITHUB_BRANCH}", headers=hdr, timeout=30)
    if r.status_code == 200:
        sha = r.json().get("sha")
    body = {"message": f"bot: image {filename}", "content": content, "branch": GITHUB_BRANCH}
    if sha:
        body["sha"] = sha
    r = requests.put(api, headers=hdr, json=body, timeout=60)
    return r.status_code in (200, 201)


def github_put_bytes(rel_path: str, data: bytes, msg: str = "bot: file") -> str | None:
    """Коммитит байты в repo/posts/<rel_path>, возвращает публичный raw-URL или None.
    Нужно для аудио: gen-api/whisper не принимает .oga из Telegram — кладём как .ogg."""
    if not GITHUB_TOKEN:
        return None
    api = f"https://api.github.com/repos/{GITHUB_REPO}/contents/posts/{rel_path}"
    hdr = {"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json",
           "User-Agent": "landwater-bot"}
    sha = None
    r = requests.get(api + f"?ref={GITHUB_BRANCH}", headers=hdr, timeout=30)
    if r.status_code == 200:
        sha = r.json().get("sha")
    put = {"message": msg, "content": base64.b64encode(data).decode(), "branch": GITHUB_BRANCH}
    if sha:
        put["sha"] = sha
    r = requests.put(api, headers=hdr, json=put, timeout=60)
    if r.status_code not in (200, 201):
        log.warning("github_put_bytes %s: HTTP %s %s", rel_path, r.status_code, r.text[:150])
        return None
    return f"https://raw.githubusercontent.com/{GITHUB_REPO}/{GITHUB_BRANCH}/posts/{rel_path}"


def publish_to_channel(cand: dict) -> bool:
    """Публикует пост ОДНИМ сообщением: крупная картинка сверху (link-preview) + ВЕСЬ текст (до 4096).
    Выбор владельца — фото над текстом в одном сообщении; тап по фото открывает ссылку (raw-URL)."""
    body = cand["body"]
    image_path = cand.get("image_path")
    image_filename = cand.get("image_filename")
    if image_path and Path(image_path).exists() and image_filename:
        github_put_image(image_filename, image_path)   # публичный raw-URL для превью над текстом
        return poster.send_message(body, image_url=poster.raw_image_url(image_filename))
    return poster.send_message(body)


# ---------------------------------------------------------------------------
# Клавиатуры
# ---------------------------------------------------------------------------
def kb_approval(cid: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚀 Сейчас", callback_data=f"ok:{cid}"),
         InlineKeyboardButton(text="🕒 По расписанию", callback_data=f"sched:{cid}")],
        [InlineKeyboardButton(text="✍️ Доработай", callback_data=f"rw:{cid}"),
         InlineKeyboardButton(text="🗑 Отменить", callback_data=f"no:{cid}")],
        [InlineKeyboardButton(text="🔄 Другая тема", callback_data=f"regen:{cid}")],
    ])


def kb_voice(cid: str, now_msk) -> InlineKeyboardMarkup:
    """Клавиатура для поста из голосовой темы: доработка/отмена + выбор слота публикации."""
    rows = [[
        InlineKeyboardButton(text="✍️ Доработай", callback_data=f"rw:{cid}"),
        InlineKeyboardButton(text="🗑 Отменить", callback_data=f"no:{cid}"),
    ]]
    slots = remaining_slots(now_msk)
    if slots:
        rows.append([InlineKeyboardButton(text=f"🕒 {hm}", callback_data=f"slot:{cid}:{idx}")
                     for idx, hm in slots])
    else:
        rows.append([InlineKeyboardButton(text="🚀 Опубликовать сейчас", callback_data=f"slot:{cid}:now")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def kb_rework_type(cid: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🖼 Картинку", callback_data=f"rt:{cid}:image"),
         InlineKeyboardButton(text="📝 Текст", callback_data=f"rt:{cid}:text")],
        [InlineKeyboardButton(text="🖼+📝 Картинку и текст", callback_data=f"rt:{cid}:both")],
        [InlineKeyboardButton(text="↩️ Назад", callback_data=f"back:{cid}")],
    ])


# ---------------------------------------------------------------------------
# Отправка кандидата владельцу на согласование
# ---------------------------------------------------------------------------
async def send_for_approval(cand: dict) -> None:
    global pending
    cid = cand["id"]
    now_msk = moscow_now()
    html = poster.markdown_to_html(poster.sanitize_for_telegram(cand["body"]))
    kind = cand.get("kind", "scheduled")

    if kind == "voice":
        header = "🎤 <b>Пост из вашего голосового.</b> Выберите время публикации или доработайте.\n\n"
    else:
        ptype = {"regular": "обычный", "humorous": "юмор", "summary": "саммари"}.get(
            cand.get("post_type"), cand.get("post_type"))
        header = f"🕒 <b>Пост на согласование</b> ({ptype}).\n\n"

    footer = ""
    src = cand.get("source_url")
    if src:
        name = cand.get("source_name") or "открыть источник"
        footer = f"\n\n🔗 <b>Источник:</b> <a href=\"{src}\">{name}</a> — сверить уникальность."

    image_path = cand.get("image_path")
    if image_path and Path(image_path).exists():
        await bot.send_photo(OWNER_ID, FSInputFile(image_path))
    kb = kb_voice(cid, now_msk) if kind == "voice" else kb_approval(cid)
    msg = await bot.send_message(
        OWNER_ID, header + html + footer, reply_markup=kb,
        link_preview_options=LinkPreviewOptions(is_disabled=True),
    )

    cand["stage"] = "await_slot" if kind == "voice" else "await_approval"
    cand["text_msg_id"] = msg.message_id
    pending = cand
    save_state()
    log.info("Кандидат %s (%s) отправлен на согласование", cid, kind)


# ---------------------------------------------------------------------------
# Расписание и таймаут
# ---------------------------------------------------------------------------
async def scheduled_tick() -> None:
    global pending
    now_msk = moscow_now()
    today = now_msk.strftime("%Y-%m-%d")
    slot = monitor.slot_of(now_msk)

    # ручной пост из голосовой темы имеет приоритет — публикуем его вместо планового
    override = pop_override(today, slot)
    if override:
        log.info("Слот %d: публикую ручной (голосовой) пост вместо планового", slot)
        ok, extra = await _publish_candidate(override)
        await _report_publish(ok, extra, "🎤 Ручной пост по расписанию (из голосового)")
        return

    async with _lock:
        if pending is not None:
            log.info("Пропускаю тик: предыдущий пост ещё на согласовании")
            return
    try:
        cand = await asyncio.to_thread(generate_candidate)
    except Exception as exc:
        log.exception("Ошибка генерации: %s", exc)
        return
    if not cand:
        log.info("Нет материала для поста в этот тик")
        return
    async with _lock:
        if pending is None:
            await send_for_approval(cand)


async def timeout_sweep() -> None:
    global pending
    async with _lock:
        if not pending:
            return
        stage = pending.get("stage")
        if stage not in ("await_approval", "await_slot"):
            return
        created = datetime.fromisoformat(pending["created_at"])
        age_min = (datetime.now(timezone.utc) - created).total_seconds() / 60
        if age_min < APPROVAL_TIMEOUT_MIN:
            return
        cand = pending
        if stage == "await_slot":
            # голосовой пост без выбранного времени — снимаем, чтобы не блокировать расписание
            pending = None
            save_state()
    if stage == "await_slot":
        try:
            await bot.send_message(OWNER_ID, "⌛️ Голосовой пост снят — время публикации не выбрано.")
        except Exception:
            pass
        return
    log.info("Таймаут согласования (%s) — авто-публикация", cand["id"])
    await do_publish(cand, reason="⏱ Авто-публикация по таймауту")


async def balance_watch() -> None:
    """Ежедневно в 10:00 МСК: баланс gen-api (картинки) и оплата сервера Timeweb.
    Пишет владельцу ТОЛЬКО если что-то требует внимания."""
    msgs = []

    bal = await asyncio.to_thread(balances.genapi_balance)
    if bal is None:
        log.warning("balance_watch: баланс gen-api недоступен")
    elif bal < GENAPI_MIN_BALANCE:
        msgs.append(
            f"🖼 <b>Картинки (gen-api.ru): {bal:.0f} ₽</b> — ниже {GENAPI_MIN_BALANCE:.0f} ₽.\n"
            f"Хватит примерно на {int(bal // 15)} обложек (~15 ₽ за штуку). "
            f"Кончится — посты будут выходить без картинок.\n"
            f"Пополнить: https://gen-api.ru"
        )

    fin = await asyncio.to_thread(balances.timeweb_finances)
    if not fin:
        log.warning("balance_watch: финансы Timeweb недоступны")
    else:
        hours = fin.get("hours_left")
        if isinstance(hours, (int, float)) and hours <= SERVER_ALERT_DAYS * 24:
            msgs.append(
                f"🖥 <b>Сервер (Timeweb): оплачен ещё ~{hours / 24:.1f} дн.</b>\n"
                f"Баланс {fin.get('balance', 0):.0f} ₽, тариф {fin.get('monthly_cost', '?')} ₽/мес.\n"
                f"Внесите абонплату — иначе сервер отключат и бот остановится: https://timeweb.cloud"
            )

    if msgs:
        try:
            await bot.send_message(OWNER_ID, "⏰ <b>Ежедневная проверка</b>\n\n" + "\n\n".join(msgs))
        except Exception as exc:
            log.warning("balance_watch: не отправил владельцу: %s", exc)
    else:
        log.info("balance_watch: балансы в норме")


async def _publish_candidate(cand: dict) -> tuple[bool, list]:
    """Публикует пост в TG-канал + fan-out в доп.каналы. НЕ трогает pending/state."""
    ok = await asyncio.to_thread(publish_to_channel, cand)
    extra = []
    try:
        extra = await asyncio.to_thread(
            channels.publish_extra, cand["body"], cand.get("image_path"), cand.get("image_filename")
        )
    except Exception as exc:
        log.warning("fan-out publish_extra: %s", exc)
    return ok, extra


async def _report_publish(ok: bool, extra: list, reason: str) -> None:
    lines = ["✅ Telegram: опубликовано" if ok else "⚠️ Telegram: ошибка"]
    for ch, cok, info in extra:
        lines.append(f"{'✅' if cok else '⚠️'} {ch}: {info}")
    await bot.send_message(OWNER_ID, "\n".join(lines) + f"\n{reason}")


async def do_publish(cand: dict, reason: str) -> None:
    global pending
    ok, extra = await _publish_candidate(cand)
    async with _lock:
        if pending is not None and pending.get("id") == cand.get("id"):
            pending = None
            save_state()
    try:
        await bot.edit_message_reply_markup(OWNER_ID, cand["text_msg_id"], reply_markup=None)
    except Exception:
        pass
    await _report_publish(ok, extra, reason)


# ---------------------------------------------------------------------------
# Обработчики кнопок
# ---------------------------------------------------------------------------
def _match(cid: str) -> bool:
    return pending is not None and pending.get("id") == cid


@dp.callback_query(F.data.startswith("ok:"))
async def on_ok(cq: CallbackQuery) -> None:
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    await cq.answer("Публикую…")
    await do_publish(pending, reason="Одобрено вручную (сейчас)")


@dp.callback_query(F.data.startswith("sched:"))
async def on_pub_sched(cq: CallbackQuery) -> None:
    global pending
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    cand = pending
    now_msk = moscow_now()
    date, slot, hm = next_publish_slot(now_msk)
    add_override(date, slot, cand)
    async with _lock:
        pending = None
        save_state()
    await cq.answer("Запланировано")
    await cq.message.edit_reply_markup(reply_markup=None)
    day = "сегодня" if date == now_msk.strftime("%Y-%m-%d") else "завтра"
    await bot.send_message(
        OWNER_ID,
        f"🕒 Пост подтверждён — выйдет <b>{day} в {hm}</b> МСК (следующий плановый слот, вместо его авто-поста)."
    )


@dp.callback_query(F.data.startswith("no:"))
async def on_cancel(cq: CallbackQuery) -> None:
    global pending
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    async with _lock:
        pending = None
        save_state()
    await cq.answer("Отменено")
    await cq.message.edit_reply_markup(reply_markup=None)
    await bot.send_message(OWNER_ID, "🗑 Пост отменён. Следующие идут по расписанию.")


@dp.callback_query(F.data.startswith("rw:"))
async def on_rework(cq: CallbackQuery) -> None:
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    pending["stage"] = "await_rework_choice"
    save_state()
    await cq.answer()
    await cq.message.edit_reply_markup(reply_markup=kb_rework_type(cid))


@dp.callback_query(F.data.startswith("back:"))
async def on_back(cq: CallbackQuery) -> None:
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer()
        return
    await cq.answer()
    if pending.get("kind") == "voice":
        pending["stage"] = "await_slot"
        save_state()
        await cq.message.edit_reply_markup(reply_markup=kb_voice(cid, moscow_now()))
    else:
        pending["stage"] = "await_approval"
        save_state()
        await cq.message.edit_reply_markup(reply_markup=kb_approval(cid))


@dp.callback_query(F.data.startswith("regen:"))
async def on_regen(cq: CallbackQuery) -> None:
    global pending
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    await cq.answer("🔄 Беру другую тему…")
    await cq.message.edit_reply_markup(reply_markup=None)
    async with _lock:
        pending = None
        save_state()
    await bot.send_message(OWNER_ID, "🔄 Генерирую пост на другую тему… (~1 мин)")
    # refresh=False → быстро из пула; ignore_limit=True → ручная перегенерация не ограничена лимитом
    cand = await asyncio.to_thread(generate_candidate, False, True)
    if not cand:
        await bot.send_message(OWNER_ID, "В пуле нет других свежих тем. Попробуйте позже или /test.")
        return
    async with _lock:
        if pending is None:
            await send_for_approval(cand)


@dp.callback_query(F.data.startswith("slot:"))
async def on_slot(cq: CallbackQuery) -> None:
    global pending
    _, cid, which = cq.data.split(":", 2)
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    cand = pending
    if which == "now":
        await cq.answer("Публикую сейчас…")
        await cq.message.edit_reply_markup(reply_markup=None)
        await do_publish(cand, reason="🎤 Ручной пост (опубликован сейчас)")
        return
    slot = int(which)
    date = moscow_now().strftime("%Y-%m-%d")
    add_override(date, slot, cand)
    async with _lock:
        pending = None
        save_state()
    await cq.answer("Запланировано")
    await cq.message.edit_reply_markup(reply_markup=None)
    h, m = monitor.POST_SLOTS_MSK[slot - 1]
    await bot.send_message(
        OWNER_ID,
        f"📌 Пост запланирован на <b>{h:02d}:{m:02d}</b> МСК — выйдет вместо планового в этот слот."
    )


@dp.callback_query(F.data.startswith("rt:"))
async def on_rework_type(cq: CallbackQuery) -> None:
    _, cid, what = cq.data.split(":", 2)
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    pending["stage"] = "await_voice"
    pending["rework_what"] = what
    save_state()
    await cq.answer()
    label = {"image": "картинку", "text": "текст", "both": "картинку и текст"}[what]
    await cq.message.edit_reply_markup(reply_markup=None)
    await bot.send_message(
        OWNER_ID,
        f"✍️ Напишите <b>текстом</b> или пришлите <b>голосовое</b> — что поправить в «{label}». "
        f"Я пересоберу пост."
    )


# ---------------------------------------------------------------------------
# Приём правок: голосовое ИЛИ текст → пересборка → новая итерация
# ---------------------------------------------------------------------------
async def _apply_correction_and_resend(correction: str) -> None:
    """Применить правку к текущему pending и отправить новую итерацию на согласование."""
    global pending
    if not pending:
        return
    what = pending.get("rework_what", "both")
    await bot.send_message(OWNER_ID, f"📝 Правка: <i>{correction}</i>\n⏳ Пересобираю…")
    try:
        cand = await asyncio.to_thread(rework_candidate, pending, what, correction)
    except Exception as exc:
        log.exception("Ошибка пересборки: %s", exc)
        await bot.send_message(OWNER_ID, f"Ошибка пересборки: {exc}")
        return

    # Обучение: если такая правка уже встречалась — делаем её постоянным правилом.
    for w in (("text", "image") if what == "both" else (what,)):
        try:
            added = await asyncio.to_thread(monitor.learn_from_correction, w, correction)
        except Exception as exc:
            log.warning("learn_from_correction(%s): %s", w, exc)
            added = None
        if added:
            label = "текста" if w == "text" else "картинки"
            await bot.send_message(
                OWNER_ID,
                f"🧠 Эта правка {label} повторяется — запомнил как постоянное правило:\n"
                f"<i>{added}</i>\nБуду учитывать в новых постах. Сбросить правила: /forget"
            )

    async with _lock:
        pending = None  # старую итерацию закрываем, отправим новую
        save_state()
    cand["created_at"] = datetime.now(timezone.utc).isoformat()  # таймер стартует заново
    cand["id"] = moscow_now().strftime("%m%d%H%M%S")
    await send_for_approval(cand)


async def _transcribe_voice(msg: Message) -> str:
    """Скачивает голосовое (.oga → кладём в GitHub как .ogg) и транскрибирует через gen-api/whisper."""
    tg_file = await bot.get_file(msg.voice.file_id)
    buf = io.BytesIO()
    await bot.download_file(tg_file.file_path, destination=buf)
    raw_url = await asyncio.to_thread(
        github_put_bytes, f"voice_{msg.message_id}.ogg", buf.getvalue(), "bot: voice"
    )
    if not raw_url:
        raise RuntimeError("не удалось выложить аудио для транскрибации")
    return await asyncio.to_thread(genapi.transcribe, raw_url)


@dp.message(F.voice)
async def on_voice(msg: Message) -> None:
    global pending
    if msg.from_user.id != OWNER_ID:
        return

    # 1) Голос как ПРАВКА к текущему посту (нажали «Доработай»)
    if pending and pending.get("stage") == "await_voice":
        await msg.reply("🎧 Расшифровываю голосовое…")
        try:
            correction = await _transcribe_voice(msg)
        except Exception as exc:
            log.exception("Ошибка транскрибации: %s", exc)
            await msg.reply(f"Не удалось расшифровать голосовое: {exc}. Можно прислать правку текстом.")
            return
        if not correction or not correction.strip():
            await msg.reply("Пустая расшифровка — повторите голосовое или напишите текстом.")
            return
        await _apply_correction_and_resend(correction.strip())
        return

    # 2) Голос вне режима правки = ТЕМА для нового поста (внепланового)
    await msg.reply("🎧 Распознаю тему и генерирую пост с картинкой… (~1–2 мин)")
    try:
        dictation = await _transcribe_voice(msg)
    except Exception as exc:
        log.exception("Ошибка транскрибации: %s", exc)
        await msg.reply(f"Не удалось расшифровать голосовое: {exc}")
        return
    if not dictation or not dictation.strip():
        await msg.reply("Пустая расшифровка — повторите голосовое.")
        return
    await bot.send_message(OWNER_ID, f"📝 Тема (распознано): <i>{dictation}</i>")
    cand = await asyncio.to_thread(generate_voice_candidate, dictation.strip())
    if not cand:
        await bot.send_message(OWNER_ID, "Не удалось собрать пост из этой записи — попробуйте переформулировать.")
        return
    await send_for_approval(cand)


@dp.message(F.text == "/start")
async def on_start(msg: Message) -> None:
    uid = msg.from_user.id
    is_owner = uid == OWNER_ID
    await msg.reply(
        "👋 Бот предварительного согласования постов канала «Землю и Воду».\n\n"
        f"Ваш chat id: <code>{uid}</code>\n"
        f"OWNER_ID в конфиге: <code>{OWNER_ID}</code> — "
        + ("совпадает ✅ буду слать посты сюда." if is_owner
           else "НЕ совпадает ⚠️ сообщите этот id.")
        + "\n\nКоманды:\n/test — сгенерировать пост сейчас\n/status — что на согласовании\n"
        "/rules — постоянные правила автора\n/forget — сбросить правила\n"
        "/balance — баланс картинок и сервера\n\n"
        "🎤 Пришлите <b>голосовое</b> (вне режима правки) — сделаю пост из вашей темы "
        "с картинкой и предложу выбрать плановое время публикации."
    )
    log.info("/start from %s (owner=%s)", uid, is_owner)


@dp.message(F.text == "/test")
async def on_test(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    if pending:
        await msg.reply(
            f"Сейчас на согласовании пост <code>{pending['id']}</code> (этап {pending.get('stage')}). "
            f"Сначала обработайте его — или /status."
        )
        return
    await msg.reply("🧪 Генерирую тестовый пост… (~1–2 мин)")
    try:
        # refresh=True, ignore_limit=True — ручной запуск не ограничен суточным лимитом
        cand = await asyncio.to_thread(generate_candidate, True, True)
    except Exception as exc:
        log.exception("/test: ошибка генерации: %s", exc)
        await msg.reply(f"⚠️ Ошибка генерации: {exc}")
        return
    if not cand:
        await msg.reply(
            "⚠️ Пост не собрался: в пуле нет подходящего свежего материала "
            "(или модель отклонила его как устаревший). Попробуйте позже."
        )
        return
    await send_for_approval(cand)


@dp.message(F.text == "/status")
async def on_status(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    if pending:
        await msg.reply(f"На согласовании: {pending['id']} (этап {pending.get('stage')})")
    else:
        await msg.reply("Сейчас ничего не на согласовании.")


@dp.message(F.text == "/rules")
async def on_rules(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    prefs = monitor.load_prefs()
    t, i = prefs.get("text", []), prefs.get("image", [])
    if not t and not i:
        await msg.reply("Постоянных правил пока нет. Они появляются, когда одна и та же правка повторяется.")
        return
    lines = ["<b>Постоянные правила автора:</b>"]
    if t:
        lines += ["", "📝 <b>Текст:</b>"] + [f"• {r}" for r in t]
    if i:
        lines += ["", "🖼 <b>Картинка:</b>"] + [f"• {r}" for r in i]
    lines.append("\nСбросить всё: /forget")
    await msg.reply("\n".join(lines))


@dp.message(F.text == "/forget")
async def on_forget(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    monitor.save_prefs({"text": [], "image": [], "log": []})
    await msg.reply("🧹 Постоянные правила и история правок сброшены.")


@dp.message(F.text == "/balance")
async def on_balance(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    await msg.reply("⏳ Проверяю балансы…")
    bal = await asyncio.to_thread(balances.genapi_balance)
    fin = await asyncio.to_thread(balances.timeweb_finances)
    lines = []
    if bal is None:
        lines.append("🖼 Картинки (gen-api.ru): не удалось получить баланс")
    else:
        mark = "⚠️" if bal < GENAPI_MIN_BALANCE else "✅"
        lines.append(f"{mark} Картинки (gen-api.ru): <b>{bal:.0f} ₽</b> (~{int(bal // 15)} обложек)")
    if not fin:
        lines.append("🖥 Сервер (Timeweb): не удалось получить данные")
    else:
        h = fin.get("hours_left") or 0
        mark = "⚠️" if h <= SERVER_ALERT_DAYS * 24 else "✅"
        lines.append(
            f"{mark} Сервер (Timeweb): <b>{fin.get('balance', 0):.0f} ₽</b> — хватит на "
            f"<b>{h / 24:.1f} дн.</b> ({fin.get('monthly_cost', '?')} ₽/мес)"
        )
    await msg.reply("\n".join(lines))


# Текстовая правка (альтернатива голосовому). Регистрируется ПОСЛЕ команд —
# /start, /test, /status матчатся своими хендлерами первыми.
@dp.message(F.text)
async def on_text_correction(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    if msg.text and msg.text.startswith("/"):
        return  # неизвестные команды игнорируем
    if not pending or pending.get("stage") != "await_voice":
        return  # правку сейчас не ждём — молчим
    correction = (msg.text or "").strip()
    if not correction:
        return
    await _apply_correction_and_resend(correction)


# ---------------------------------------------------------------------------
# Health-сервер (galaxy-app мониторит порт) + запуск
# ---------------------------------------------------------------------------
async def health(_req):
    return web.json_response({"ok": True, "pending": bool(pending)})


async def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    load_state()

    app = web.Application()
    app.router.add_get("/health", health)
    app.router.add_get("/", health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()
    log.info("Health-сервер на :%d", PORT)

    sched = AsyncIOScheduler(timezone="UTC")
    for h, m in SLOTS_UTC:
        sched.add_job(scheduled_tick, "cron", hour=h, minute=m, misfire_grace_time=600)
    sched.add_job(timeout_sweep, "interval", seconds=60)
    sched.add_job(balance_watch, "cron", hour=BALANCE_CHECK_UTC[0], minute=BALANCE_CHECK_UTC[1],
                  misfire_grace_time=3600)
    sched.start()
    log.info("Планировщик запущен: %d слотов + таймаут-свип + мониторинг балансов %02d:%02d UTC (10:00 МСК)",
             len(SLOTS_UTC), *BALANCE_CHECK_UTC)

    # снять вебхук, иначе getUpdates вернёт 409 Conflict и polling упадёт
    try:
        await bot.delete_webhook(drop_pending_updates=True)
    except Exception as exc:
        log.warning("delete_webhook: %s", exc)

    try:
        await bot.send_message(OWNER_ID, "🤖 Бот согласования запущен. Жду посты по расписанию.")
    except Exception as exc:
        log.warning("Не удалось отправить стартовое сообщение владельцу: %s", exc)

    log.info("Старт long-polling…")
    await dp.start_polling(bot, handle_signals=False)


if __name__ == "__main__":
    asyncio.run(main())
