#!/usr/bin/env python3
"""
bot.py — Telegram-бот предварительного согласования постов канала «Землю и Воду».

Поток:
  расписание → генерация поста-кандидата (reuse scripts/monitor.py)
  → отправка владельцу на согласование (фото + текст + 3 кнопки)
  → «✅ Ок»       → публикация в канал (reuse scripts/poster.py)
  → «✍️ Доработай» → выбор [Картинку/Текст/Картинку+текст] → голосовое →
                     транскрибация (OpenAI Whisper) → пересборка → новая итерация
  → «🗑 Отменить»  → отмена без замены, расписание продолжается
  → нет ответа за APPROVAL_TIMEOUT_MIN минут → авто-публикация
"""

import asyncio
import base64
import json
import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests
from aiohttp import web
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from dotenv import load_dotenv

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

load_dotenv()

# --- переиспользуем существующие генерацию и публикацию ------------------------
import scripts.monitor as monitor
import scripts.poster as poster

# ---------------------------------------------------------------------------
# Конфигурация
# ---------------------------------------------------------------------------
BOT_TOKEN = os.getenv("BOT_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", "8118456427"))
CHANNEL_ID = os.getenv("CHANNEL_ID")
DATA_DIR = Path(os.getenv("DATA_DIR", "/opt/app/data"))
STATE_FILE = DATA_DIR / "state.json"
APPROVAL_TIMEOUT_MIN = int(os.getenv("APPROVAL_TIMEOUT_MIN", "30"))
PORT = int(os.getenv("PORT", "3000"))
MOSCOW_OFFSET = timedelta(hours=3)

# GitHub — публичный raw-URL картинки (Black Hole сервер сам её не отдаёт)
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_REPO = os.getenv("GITHUB_REPO", "Kedros64/telegram-channel-land-water")
GITHUB_BRANCH = os.getenv("GITHUB_BRANCH", "main")

# Слоты генерации (UTC) — как в GitHub Actions, но здесь запускаются точно по времени
SLOTS_UTC = [(6, 10), (8, 30), (10, 10), (12, 30), (14, 10), (16, 30), (17, 10)]

WHISPER_MODEL = "gpt-4o-mini-transcribe"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("bot")

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# ---------------------------------------------------------------------------
# Состояние (одно «на согласовании» за раз; при желании расширяется в очередь)
# ---------------------------------------------------------------------------
# pending = {id, body, raw_text, image_path, image_filename, post_type,
#            created_at, text_msg_id, stage, rework_what}
#   stage: "await_approval" | "await_rework_choice" | "await_voice"
pending: dict | None = None
_lock = asyncio.Lock()


def moscow_now() -> datetime:
    return datetime.now(timezone.utc) + MOSCOW_OFFSET


def save_state() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(
        json.dumps(pending, ensure_ascii=False, default=str), encoding="utf-8"
    )


def load_state() -> None:
    global pending
    if STATE_FILE.exists():
        try:
            pending = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            log.warning("Не удалось прочитать state.json: %s", exc)
            pending = None


# ---------------------------------------------------------------------------
# Генерация кандидата (reuse monitor)
# ---------------------------------------------------------------------------
def generate_candidate() -> dict | None:
    """Синхронно генерит один пост-кандидат. Возвращает dict или None (нет материала)."""
    if not monitor.DEEPSEEK_API_KEY:
        log.error("DEEPSEEK_API_KEY не задан")
        return None

    now_msk = moscow_now()
    post_type = monitor.detect_post_type(now_msk)
    today = now_msk.strftime("%Y-%m-%d")

    sources = monitor.read_sources()
    all_articles = monitor.collect_all_articles(sources)
    pool = monitor.load_articles_pool()
    if all_articles:
        pre = monitor.pre_filter_by_keywords(all_articles)
        relevant = monitor.filter_relevant_with_deepseek(pre) if pre else []
        pool = monitor.merge_into_pool(pool, relevant, now_msk)

    count = monitor.SUMMARY_POST_ARTICLES if post_type == "summary" else 1
    selected = monitor.select_posts_from_pool(pool, today, count=count)
    if not selected:
        monitor.save_articles_pool(pool)
        return None

    urls = {a["url"] for a in selected}
    for a in pool:
        if a.get("url") in urls:
            a["used"] = True
            a["used_at"] = now_msk.isoformat()
    monitor.save_articles_pool(pool)

    session = monitor.make_session()
    for a in selected:
        u = a.get("url", "")
        if u and not monitor.validate_url(u, session):
            a["url"] = ""

    if post_type == "summary":
        raw_text = monitor.generate_summary_post(selected)
        article = {"title": f"Дайджест дня: {len(selected)} новостей", "source_name": "Саммари", "url": ""}
    else:
        article = selected[0]
        raw_text = monitor.generate_post(article, post_type=post_type)
        if raw_text.strip().upper().startswith("SKIP"):
            log.info("Материал отклонён моделью (SKIP)")
            return None

    image_path = None
    if monitor.OPENAI_API_KEY:
        img_prompt = monitor.extract_image_prompt(raw_text)
        if img_prompt:
            img_fmt = monitor.extract_image_format(raw_text)
            p = monitor.generate_image(img_prompt, now_msk, 1, img_fmt)
            image_path = str(p) if p else None

    body = poster._clean_post_body(raw_text) or raw_text.strip()
    return {
        "id": now_msk.strftime("%m%d%H%M%S"),
        "body": body,
        "raw_text": raw_text,
        "image_path": image_path,
        "image_filename": Path(image_path).name if image_path else None,
        "post_type": post_type,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Доработка (reuse DeepSeek / image gen)
# ---------------------------------------------------------------------------
REWORK_PROMPT = """\
Ты — редактор Telegram-канала компании о земле и воде. Ниже текущий пост и правка автора.
Перепиши пост с учётом правки, сохранив живой человеческий тон от лица КОМАНДЫ компании
(мы/наша команда) и ТОЧНО тот же выходной формат: блок «**ГОТОВЫЙ ПОСТ:**», затем текст,
затем «**ВИЗУАЛ:**» с «Формат:» и «Prompt (EN):».

ТЕКУЩИЙ ПОСТ:
{current}

ПРАВКА АВТОРА (расшифровка голосового):
{correction}
"""


def rework_candidate(cand: dict, what: str, correction: str) -> dict:
    """Применяет правку к кандидату. what: 'text' | 'image' | 'both'."""
    now_msk = moscow_now()
    raw_text = cand["raw_text"]

    if what in ("text", "both"):
        raw_text = monitor.deepseek_generate(
            REWORK_PROMPT.format(current=cand["raw_text"], correction=correction)
        )
        cand["raw_text"] = raw_text
        cand["body"] = poster._clean_post_body(raw_text) or raw_text.strip()

    if what in ("image", "both") and monitor.OPENAI_API_KEY:
        img_prompt = monitor.extract_image_prompt(raw_text)
        # для правки только картинки — добавим пожелание автора в промпт
        if what == "image" and correction:
            img_prompt = f"{img_prompt}. Правка: {correction}"
        if img_prompt:
            img_fmt = monitor.extract_image_format(raw_text)
            p = monitor.generate_image(img_prompt, now_msk, 1, img_fmt)
            if p:
                cand["image_path"] = str(p)
                cand["image_filename"] = Path(p).name
    return cand


def transcribe_voice(ogg_path: str) -> str:
    """Расшифровка голосового через OpenAI Whisper."""
    with open(ogg_path, "rb") as f:
        resp = requests.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {monitor.OPENAI_API_KEY}"},
            files={"file": (os.path.basename(ogg_path), f, "audio/ogg")},
            data={"model": WHISPER_MODEL, "language": "ru"},
            timeout=120,
        )
    resp.raise_for_status()
    return resp.json().get("text", "").strip()


# ---------------------------------------------------------------------------
# Публикация в канал (reuse poster + коммит картинки в GitHub для raw-URL)
# ---------------------------------------------------------------------------
def github_put_image(filename: str, local_path: str) -> bool:
    """Коммитит PNG в репозиторий, чтобы получить публичный raw-URL для превью."""
    if not GITHUB_TOKEN:
        return False
    api = f"https://api.github.com/repos/{GITHUB_REPO}/contents/posts/{filename}"
    hdr = {"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json",
           "User-Agent": "landwater-bot"}
    content = base64.b64encode(open(local_path, "rb").read()).decode()
    # sha, если файл уже есть
    sha = None
    r = requests.get(api + f"?ref={GITHUB_BRANCH}", headers=hdr, timeout=30)
    if r.status_code == 200:
        sha = r.json().get("sha")
    body = {"message": f"bot: image {filename}", "content": content, "branch": GITHUB_BRANCH}
    if sha:
        body["sha"] = sha
    r = requests.put(api, headers=hdr, json=body, timeout=60)
    return r.status_code in (200, 201)


def publish_to_channel(cand: dict) -> bool:
    """Публикует пост в канал одним сообщением (картинка в теле)."""
    body = cand["body"]
    image_path = cand.get("image_path")
    image_filename = cand.get("image_filename")
    plain_len = len(poster.sanitize_for_telegram(body))

    if image_path and Path(image_path).exists() and plain_len <= poster.TELEGRAM_CAPTION_MAX:
        return poster.send_photo(Path(image_path), caption=body)
    if image_filename and image_path and Path(image_path).exists():
        github_put_image(image_filename, image_path)  # для raw-URL превью
        return poster.send_message(body, image_url=poster.raw_image_url(image_filename))
    return poster.send_message(body)


# ---------------------------------------------------------------------------
# Клавиатуры
# ---------------------------------------------------------------------------
def kb_approval(cid: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Ок", callback_data=f"ok:{cid}"),
        InlineKeyboardButton(text="✍️ Доработай", callback_data=f"rw:{cid}"),
        InlineKeyboardButton(text="🗑 Отменить", callback_data=f"no:{cid}"),
    ]])


def kb_rework_type(cid: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🖼 Картинку", callback_data=f"rt:{cid}:image"),
         InlineKeyboardButton(text="📝 Текст", callback_data=f"rt:{cid}:text")],
        [InlineKeyboardButton(text="🖼+📝 Картинку и текст", callback_data=f"rt:{cid}:both")],
        [InlineKeyboardButton(text="↩️ Назад", callback_data=f"back:{cid}")],
    ])


# ---------------------------------------------------------------------------
# Отправка кандидата владельцу на согласование
# ---------------------------------------------------------------------------
async def send_for_approval(cand: dict) -> None:
    global pending
    cid = cand["id"]
    html = poster.markdown_to_html(poster.sanitize_for_telegram(cand["body"]))
    ptype = {"regular": "обычный", "humorous": "юмор", "summary": "саммари"}.get(cand["post_type"], cand["post_type"])
    header = f"🕒 <b>Пост на согласование</b> ({ptype}). Авто-публикация через {APPROVAL_TIMEOUT_MIN} мин.\n\n"

    image_path = cand.get("image_path")
    if image_path and Path(image_path).exists():
        await bot.send_photo(OWNER_ID, FSInputFile(image_path))
    msg = await bot.send_message(OWNER_ID, header + html, reply_markup=kb_approval(cid))

    cand["stage"] = "await_approval"
    cand["text_msg_id"] = msg.message_id
    pending = cand
    save_state()
    log.info("Кандидат %s отправлен на согласование", cid)


# ---------------------------------------------------------------------------
# Расписание и таймаут
# ---------------------------------------------------------------------------
async def scheduled_tick() -> None:
    global pending
    async with _lock:
        if pending is not None:
            log.info("Пропускаю тик: предыдущий пост ещё на согласовании")
            return
    try:
        cand = await asyncio.to_thread(generate_candidate)
    except Exception as exc:
        log.exception("Ошибка генерации: %s", exc)
        return
    if not cand:
        log.info("Нет материала для поста в этот тик")
        return
    async with _lock:
        if pending is None:
            await send_for_approval(cand)


async def timeout_sweep() -> None:
    global pending
    async with _lock:
        if not pending or pending.get("stage") != "await_approval":
            return
        created = datetime.fromisoformat(pending["created_at"])
        age_min = (datetime.now(timezone.utc) - created).total_seconds() / 60
        if age_min < APPROVAL_TIMEOUT_MIN:
            return
        cand = pending
    log.info("Таймаут согласования (%s) — авто-публикация", cand["id"])
    await do_publish(cand, reason="⏱ Авто-публикация по таймауту")


async def do_publish(cand: dict, reason: str) -> None:
    global pending
    ok = await asyncio.to_thread(publish_to_channel, cand)
    async with _lock:
        pending = None
        save_state()
    try:
        await bot.edit_message_reply_markup(OWNER_ID, cand["text_msg_id"], reply_markup=None)
    except Exception:
        pass
    await bot.send_message(OWNER_ID, ("✅ Опубликовано в канал." if ok else "⚠️ Ошибка публикации.") + f"\n{reason}")


# ---------------------------------------------------------------------------
# Обработчики кнопок
# ---------------------------------------------------------------------------
def _match(cid: str) -> bool:
    return pending is not None and pending.get("id") == cid


@dp.callback_query(F.data.startswith("ok:"))
async def on_ok(cq: CallbackQuery) -> None:
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    await cq.answer("Публикую…")
    await do_publish(pending, reason="Одобрено вручную")


@dp.callback_query(F.data.startswith("no:"))
async def on_cancel(cq: CallbackQuery) -> None:
    global pending
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    async with _lock:
        pending = None
        save_state()
    await cq.answer("Отменено")
    await cq.message.edit_reply_markup(reply_markup=None)
    await bot.send_message(OWNER_ID, "🗑 Пост отменён. Следующие идут по расписанию.")


@dp.callback_query(F.data.startswith("rw:"))
async def on_rework(cq: CallbackQuery) -> None:
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    pending["stage"] = "await_rework_choice"
    save_state()
    await cq.answer()
    await cq.message.edit_reply_markup(reply_markup=kb_rework_type(cid))


@dp.callback_query(F.data.startswith("back:"))
async def on_back(cq: CallbackQuery) -> None:
    cid = cq.data.split(":", 1)[1]
    if not _match(cid):
        await cq.answer()
        return
    pending["stage"] = "await_approval"
    save_state()
    await cq.answer()
    await cq.message.edit_reply_markup(reply_markup=kb_approval(cid))


@dp.callback_query(F.data.startswith("rt:"))
async def on_rework_type(cq: CallbackQuery) -> None:
    _, cid, what = cq.data.split(":", 2)
    if not _match(cid):
        await cq.answer("Этот пост уже обработан", show_alert=True)
        return
    pending["stage"] = "await_voice"
    pending["rework_what"] = what
    save_state()
    await cq.answer()
    label = {"image": "картинку", "text": "текст", "both": "картинку и текст"}[what]
    await cq.message.edit_reply_markup(reply_markup=None)
    await bot.send_message(
        OWNER_ID,
        f"🎤 Пришлите <b>голосовое</b> с тем, что поправить в «{label}». Я расшифрую и пересоберу пост."
    )


# ---------------------------------------------------------------------------
# Голосовое сообщение с правками
# ---------------------------------------------------------------------------
@dp.message(F.voice)
async def on_voice(msg: Message) -> None:
    global pending
    if msg.from_user.id != OWNER_ID:
        return
    if not pending or pending.get("stage") != "await_voice":
        await msg.reply("Сейчас правки не жду. Нажмите «Доработай» под постом.")
        return

    what = pending.get("rework_what", "both")
    await msg.reply("🎧 Расшифровываю и вношу правки…")

    ogg = DATA_DIR / f"voice_{pending['id']}.oga"
    try:
        tg_file = await bot.get_file(msg.voice.file_id)
        await bot.download_file(tg_file.file_path, destination=str(ogg))
        correction = await asyncio.to_thread(transcribe_voice, str(ogg))
    except Exception as exc:
        log.exception("Ошибка транскрибации: %s", exc)
        await msg.reply(f"Не удалось расшифровать голосовое: {exc}")
        return
    finally:
        try:
            ogg.unlink(missing_ok=True)
        except Exception:
            pass

    if not correction:
        await msg.reply("Пустая расшифровка — повторите голосовое.")
        return
    await bot.send_message(OWNER_ID, f"📝 Расшифровка: <i>{correction}</i>")

    try:
        cand = await asyncio.to_thread(rework_candidate, pending, what, correction)
    except Exception as exc:
        log.exception("Ошибка пересборки: %s", exc)
        await msg.reply(f"Ошибка пересборки: {exc}")
        return

    async with _lock:
        pending = None  # старую итерацию закрываем, отправим новую
        save_state()
    cand["created_at"] = datetime.now(timezone.utc).isoformat()  # таймер стартует заново
    cand["id"] = moscow_now().strftime("%m%d%H%M%S")
    await send_for_approval(cand)


@dp.message(F.text == "/start")
async def on_start(msg: Message) -> None:
    uid = msg.from_user.id
    is_owner = uid == OWNER_ID
    await msg.reply(
        "👋 Бот предварительного согласования постов канала «Землю и Воду».\n\n"
        f"Ваш chat id: <code>{uid}</code>\n"
        f"OWNER_ID в конфиге: <code>{OWNER_ID}</code> — "
        + ("совпадает ✅ буду слать посты сюда." if is_owner
           else "НЕ совпадает ⚠️ сообщите этот id.")
        + "\n\nКоманды: /test — сгенерировать пост сейчас, /status — что на согласовании."
    )
    log.info("/start from %s (owner=%s)", uid, is_owner)


@dp.message(F.text == "/test")
async def on_test(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    await msg.reply("🧪 Генерирую тестовый пост на согласование… (~1–2 мин)")
    asyncio.create_task(scheduled_tick())


@dp.message(F.text == "/status")
async def on_status(msg: Message) -> None:
    if msg.from_user.id != OWNER_ID:
        return
    if pending:
        await msg.reply(f"На согласовании: {pending['id']} (этап {pending.get('stage')})")
    else:
        await msg.reply("Сейчас ничего не на согласовании.")


# ---------------------------------------------------------------------------
# Health-сервер (galaxy-app мониторит порт) + запуск
# ---------------------------------------------------------------------------
async def health(_req):
    return web.json_response({"ok": True, "pending": bool(pending)})


async def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    load_state()

    app = web.Application()
    app.router.add_get("/health", health)
    app.router.add_get("/", health)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()
    log.info("Health-сервер на :%d", PORT)

    sched = AsyncIOScheduler(timezone="UTC")
    for h, m in SLOTS_UTC:
        sched.add_job(scheduled_tick, "cron", hour=h, minute=m, misfire_grace_time=600)
    sched.add_job(timeout_sweep, "interval", seconds=60)
    sched.start()
    log.info("Планировщик запущен: %d слотов + таймаут-свип", len(SLOTS_UTC))

    # снять вебхук, иначе getUpdates вернёт 409 Conflict и polling упадёт
    try:
        await bot.delete_webhook(drop_pending_updates=True)
    except Exception as exc:
        log.warning("delete_webhook: %s", exc)

    try:
        await bot.send_message(OWNER_ID, "🤖 Бот согласования запущен. Жду посты по расписанию.")
    except Exception as exc:
        log.warning("Не удалось отправить стартовое сообщение владельцу: %s", exc)

    log.info("Старт long-polling…")
    await dp.start_polling(bot, handle_signals=False)


if __name__ == "__main__":
    asyncio.run(main())
